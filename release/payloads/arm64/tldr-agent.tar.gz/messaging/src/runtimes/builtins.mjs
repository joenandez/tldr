// The immutable builtin runtime data. Seeded verbatim from
// src/daemon/runtime_table.mjs (whose entries are copied verbatim from
// Helm at revision 3545a719) plus the identity, hook-install, and
// capability evidence those modules carry hardcoded today:
//
//   templates        <- runtime_table.mjs resumeArgs/spawnArgs, with the
//                       substituted slot made a whole-element literal
//                       ({sessionId}/{prompt}) instead of a function
//   identity         <- src/cli/hook_identity.mjs SESSION_ENV_CHAIN (:20)
//                       and the resolveRuntime sniffer (:195-205), split
//                       per runtime in resolve order
//   hooksInstall     <- src/cli/hooks_install.mjs settingsPathFor (:86-90)
//
// Plan W1 «Layering (structural)»: this file is data only and imports
// nothing from any other source layer. A runtime absent from this data is
// not an error: its resume requests stay `pending` for an external
// `resume.claim` (docs/protocol.md «Resume requests»).
//
// resume_session.mjs:196-198 records the `--resume` (claude) versus
// `exec resume` (codex) inversion as a prior Helm regression — the two
// runtimes put the same idea in different argument positions, so the
// vectors are copied rather than derived. Never abbreviate them.

export const BUILTIN_RUNTIMES = Object.freeze({
  'claude-code': Object.freeze({
    id: 'claude-code',
    contractVersion: '1.0',
    // Loader-known metadata: set here, never serialized onto the wire or
    // into state, and never adapter-authored (a manifest declaring it is
    // rejected at parse time).
    origin: 'builtin',
    resumeStrategy: 'daemon',
    command: 'claude',
    // Neither vector carries a positional prompt: the resumer runs Claude
    // under the run host (cli/run_host.mjs), which writes the brief as
    // a stream-json user line and keeps stdin open for later prompts. A
    // spawn names the session id the resumer mints for it.
    resumeArgsTemplate: Object.freeze(['--resume', '{sessionId}', '--dangerously-skip-permissions', '-p', '--verbose', '--output-format', 'stream-json', '--input-format', 'stream-json']),
    spawnArgsTemplate: Object.freeze(['-p', '--verbose', '--output-format', 'stream-json', '--input-format', 'stream-json', '--dangerously-skip-permissions', '--session-id', '{sessionId}']),
    identity: Object.freeze({
      sessionEnvVars: Object.freeze(['CLAUDE_SESSION_ID', 'CLAUDE_CODE_SESSION_ID']),
      envMarkers: Object.freeze(['CLAUDECODE', 'CLAUDE_CODE_SESSION_ID', 'CLAUDE_SESSION_ID']),
      transcriptHints: Object.freeze(['/.claude/', '/claude/projects/']),
    }),
    hooksInstall: Object.freeze({ settingsPath: '.claude/settings.json', format: 'claude-json' }),
    // An async-rewake Stop listener wakes the idle session without holding
    // Claude Code's input queue, so background-task notifications still land.
    capabilities: Object.freeze({ stdoutInjection: true, blockExitCodes: Object.freeze([2]), idleWake: 'background-hook' }),
    // ac-kf9rt R2b: the stdin brief carries user bodies, because this runtime's UserPromptSubmit is proven
    // to fire for it (11-26 probe), so the launch's busy mark receipts them. Builtin data only. Codex lacks
    // it until its app-server UPS probe (AC10) passes.
    briefBodyReceipt: true,
  }),
  codex: Object.freeze({
    id: 'codex',
    contractVersion: '1.0',
    origin: 'builtin',
    resumeStrategy: 'daemon',
    command: 'codex',
    // The resumer runs Codex under the run host (cli/run_host.mjs),
    // which drives `codex app-server` over JSON-RPC: the thread to resume
    // and the launch policy are run host flags, and the brief arrives on
    // stdin, so neither vector carries a slot.
    resumeArgsTemplate: Object.freeze(['app-server']),
    spawnArgsTemplate: Object.freeze(['app-server']),
    // F34: a thread the managed app-server hosts (its TUI exited or died; the
    // app-server keeps the writer lock) cannot be resumed by a second `codex
    // exec`. `codex queue` hands the brief to that app-server instead, which
    // runs it as the next turn of the same session once the current turn
    // ends. Codex only: a builtin-data field, never read from a manifest.
    hostedQueueArgsTemplate: Object.freeze(['queue', '--thread', '{sessionId}', '--message', '{prompt}']),
    identity: Object.freeze({
      sessionEnvVars: Object.freeze(['CODEX_THREAD_ID']),
      envMarkers: Object.freeze(['CODEX_THREAD_ID']),
      transcriptHints: Object.freeze(['/.codex/', '/codex/sessions/']),
    }),
    hooksInstall: Object.freeze({ settingsPath: '.codex/hooks.json', format: 'claude-json' }),
    // Codex async hooks cannot wake an idle session, so the blocking Stop
    // park is its only idle wake.
    capabilities: Object.freeze({ stdoutInjection: true, blockExitCodes: Object.freeze([2]), idleWake: 'stop-hold' }),
  }),
});

/** Every canonical id, in table order. */
export const CANONICAL_RUNTIME_IDS = Object.freeze(Object.keys(BUILTIN_RUNTIMES));

/**
 * Legacy stored ids that must compare equal to a canonical id. Rows
 * persisted under these spellings are never rewritten; new rows store the
 * canonical id (plan W1 «Canonical ids and legacy equivalence»). codex has
 * no legacy alias.
 */
export const LEGACY_RUNTIME_ALIASES = Object.freeze({
  claude: 'claude-code',
});
