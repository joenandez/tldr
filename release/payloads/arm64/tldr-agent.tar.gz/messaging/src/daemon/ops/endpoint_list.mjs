// endpoint.list — docs/protocol.md "Principal and endpoint lifecycle".
//
// A caller-scoped, read-only projection of the endpoints the authenticated
// application registered. The session hooks register one endpoint per
// agent session, so this is where the session facts live: the provider
// session id, the runtime, busy/idle state, launch mode, the workspace
// reference the session reported, and the proven Codex owner pid. A
// sibling component (Helm's scheduler) reads those facts through the CLI
// instead of keeping its own session hooks.
//
// It never creates or changes a row, never returns an endpoint another
// application created, and never returns an endpoint under an authority the
// caller's register_endpoints grant does not cover — the same ownership rule
// endpoint.retirement.get and principal.resolve apply. Closed endpoints are
// omitted unless asked for, because a closed session never returns.

import { createHash } from 'node:crypto';
import { TightbeamError } from '../../protocol/envelope.mjs';
import { normalizeStartIdentity } from '../owner_process_contract.mjs';
import { isTachyonArmedForGeneration } from '../tachyon_arming.mjs';
import { expandStoredRuntimeIds, runtimeContract } from './resume_shared.mjs';

const FIELDS = new Set(['authority_name', 'endpoint_id', 'provider_session_id', 'provider_session_id_prefix', 'authority_reference', 'runtime', 'created_after', 'created_before', 'active_after', 'order_by', 'include_closed', 'limit']);
export const ENDPOINT_LIST_DEFAULT_LIMIT = 100;
export const ENDPOINT_LIST_MAX_LIMIT = 1000;

function malformed(field, message) {
  throw new TightbeamError('malformed_request', message, { field });
}

function optionalString(payload, field) {
  const value = payload[field];
  if (value === undefined || value === null) return null;
  if (typeof value !== 'string' || value.length === 0) malformed(field, `${field} must be a non-empty string when present`);
  return value;
}

// Stored timestamps are Date#toISOString() strings, which order correctly
// as text. A bound is normalized to that exact shape so the comparison in
// SQL stays a plain string comparison.
function optionalTimestamp(payload, field) {
  const value = optionalString(payload, field);
  if (value === null) return null;
  const ms = Date.parse(value);
  if (!Number.isFinite(ms)) malformed(field, `${field} must be an ISO-8601 timestamp`);
  return new Date(ms).toISOString();
}

function parsePayload(payload) {
  if (payload === undefined || payload === null) payload = {};
  if (typeof payload !== 'object' || Array.isArray(payload)) malformed('payload', 'endpoint.list payload must be an object');
  const unknown = Object.keys(payload).find((key) => !FIELDS.has(key));
  if (unknown) malformed(unknown, `endpoint.list does not accept ${unknown}`);
  const includeClosed = payload.include_closed ?? false;
  if (typeof includeClosed !== 'boolean') malformed('include_closed', 'include_closed must be a boolean when present');
  const limit = payload.limit ?? ENDPOINT_LIST_DEFAULT_LIMIT;
  if (!Number.isInteger(limit) || limit < 1 || limit > ENDPOINT_LIST_MAX_LIMIT) {
    malformed('limit', `limit must be an integer from 1 to ${ENDPOINT_LIST_MAX_LIMIT}`);
  }
  const orderBy = payload.order_by ?? 'created_at';
  if (orderBy !== 'created_at' && orderBy !== 'updated_at') malformed('order_by', 'order_by must be created_at or updated_at when present');
  return {
    authorityName: optionalString(payload, 'authority_name'),
    endpointId: optionalString(payload, 'endpoint_id'),
    providerSessionId: optionalString(payload, 'provider_session_id'),
    providerSessionIdPrefix: optionalString(payload, 'provider_session_id_prefix'),
    authorityReference: optionalString(payload, 'authority_reference'),
    runtime: optionalString(payload, 'runtime'),
    createdAfter: optionalTimestamp(payload, 'created_after'),
    createdBefore: optionalTimestamp(payload, 'created_before'),
    activeAfter: optionalTimestamp(payload, 'active_after'),
    orderBy,
    includeClosed,
    limit,
  };
}

// ac-jfv.116: what the reconciler's last pass saw of this owner (daemon memory;
// a fact about one exact owner: same pid, start identity and generation, so a
// replaced process drops it) and, for a busy owner, what it is doing. A held
// background Stop comes from the listener row. Null when nothing is known.
function seenOwner(context, row) {
  const seen = context.ownerActivity?.get(row.id);
  const key = [row.owner_process_pid, normalizeStartIdentity(row.owner_process_start_identity), row.process_generation];
  const sameOwner = seen && [seen.owner_process_pid, seen.owner_process_start_identity, seen.process_generation].every((value, i) => value === key[i]);
  return sameOwner && !row.owner_process_exited_at && row.owner_process_generation === row.process_generation ? seen : null;
}

function ownerActivity(context, row) {
  const seen = seenOwner(context, row);
  // Activity is a fact about an observed live owner; without that observation it is unknown.
  const held = seen && row.state === 'idle' && row.background_wait_since;
  const activity = seen && row.state === 'busy' ? seen.activity : held ? 'waiting_on_background' : null;
  const since = seen && row.state === 'busy' ? seen.waiting_since : held ? row.background_wait_since : null;
  return { owner_observed_alive: seen ? true : null, owner_activity: activity, owner_waiting_since: since };
}

function projection(context, row) {
  return {
    endpoint_id: row.id,
    principal_id: row.principal_id,
    authority_name: row.authority_name,
    runtime: row.runtime ?? null,
    provider_session_id: row.provider_session_id ?? null,
    state: row.state,
    process_generation: row.process_generation ?? null,
    // A digest, never the token: a hook tells another launch's custody from its own (ac-x09n0).
    owner_launch_digest: row.owner_launch_token ? `sha256:${createHash('sha256').update(row.owner_launch_token, 'utf8').digest('hex')}` : null,
    launch_mode: row.launch_mode ?? null,
    authority_reference: row.authority_reference ?? null,
    academy_agent_name: row.academy_agent_name ?? null,
    owner_process_pid: row.owner_process_pid ?? null,
    owner_process_exited_at: row.owner_process_exited_at ?? null,
    tachyon_armed: isTachyonArmedForGeneration(row, row.process_generation),
    ...ownerActivity(context, row),
    superseded_by_endpoint_id: row.superseded_by_endpoint_id ?? null,
    created_at: row.created_at,
    updated_at: row.updated_at,
    closed_at: row.closed_at ?? null,
  };
}

// One authority narrows inside the query, before the limit: a filter after it can miss the row.
function listedAuthorities(grant, authorityName) {
  const granted = Array.isArray(grant?.allowed_authorities) ? grant.allowed_authorities : [];
  return authorityName === null ? granted : granted.filter((name) => name === authorityName);
}

export const endpointListOp = {
  name: 'endpoint.list',
  allowedScopes: ['agent'],
  permission: 'register_endpoints',
  handler(context, payload, connection) {
    const filters = parsePayload(payload);
    const grant = connection.permissions.get('register_endpoints');
    const authorities = listedAuthorities(grant, filters.authorityName);
    if (authorities.length === 0) return { result: { endpoints: [], truncated: false } };

    const where = ['created_by_app_id = ?', `authority_name IN (${authorities.map(() => '?').join(', ')})`];
    const params = [connection.appId, ...authorities];
    // The exact id and the literal prefix are bounded reads a caller can use
    // to prove a fact without depending on the capped, newest-first list.
    if (filters.endpointId !== null) {
      where.push('id = ?');
      params.push(filters.endpointId);
    }
    if (filters.providerSessionIdPrefix !== null) {
      where.push('substr(provider_session_id, 1, ?) = ?');
      params.push(filters.providerSessionIdPrefix.length, filters.providerSessionIdPrefix);
    }
    if (filters.authorityReference !== null) {
      where.push('authority_reference = ?');
      params.push(filters.authorityReference);
    }
    if (filters.providerSessionId !== null) {
      where.push('provider_session_id = ?');
      params.push(filters.providerSessionId);
    }
    if (filters.runtime !== null) {
      // 'claude' and 'claude-code' name one runtime; a filter on either
      // spelling must find rows stored under both.
      const spellings = expandStoredRuntimeIds([filters.runtime], runtimeContract(context).acceptedStoredIds);
      where.push(`runtime IN (${spellings.map(() => '?').join(', ')})`);
      params.push(...spellings);
    }
    if (filters.createdAfter !== null) {
      where.push('created_at >= ?');
      params.push(filters.createdAfter);
    }
    if (filters.createdBefore !== null) {
      where.push('created_at <= ?');
      params.push(filters.createdBefore);
    }
    if (filters.activeAfter !== null) {
      // Recently changed, or live now: a recorded owner with no observed exit.
      where.push("(updated_at >= ? OR (owner_process_pid IS NOT NULL AND owner_process_exited_at IS NULL AND state NOT IN ('dead', 'closed')))");
      params.push(filters.activeAfter);
    }
    if (!filters.includeClosed) where.push("state != 'closed'");

    // One extra row answers "was the result cut off" without a COUNT.
    const rows = context.db
      .prepare(
        `SELECT id, principal_id, authority_name, runtime, provider_session_id, state, launch_mode,
                authority_reference, academy_agent_name, owner_process_pid, owner_process_exited_at, owner_process_start_identity, owner_process_generation, process_generation, owner_launch_token,
                tachyon_armed_process_generation, created_at, updated_at, closed_at,
                (SELECT original.replacement_endpoint_id FROM resume_requests original
                  WHERE original.endpoint_id = endpoints.id
                    AND original.state = 'failed' AND original.recovery_mode = 'exact_resume'
                    AND original.replacement_endpoint_id IS NOT NULL
                  LIMIT 1) AS superseded_by_endpoint_id,
                (SELECT MIN(held.background_wait_at) FROM listeners held
                  WHERE held.endpoint_id = endpoints.id AND held.process_generation = endpoints.process_generation
                    AND held.state IN ('parked', 'attached', 'waking') AND held.background_wait_at IS NOT NULL) AS background_wait_since
           FROM endpoints
          WHERE ${where.join(' AND ')}
          ORDER BY ${filters.orderBy} DESC, id DESC
          LIMIT ?`,
      )
      .all(...params, filters.limit + 1);
    const truncated = rows.length > filters.limit;
    return { result: { endpoints: rows.slice(0, filters.limit).map((row) => projection(context, row)), truncated } };
  },
};
