// message.receive's last receipt path: a live session's own unread delivery.

import { TightbeamError } from "../../protocol/envelope.mjs";
import { markExactDeliveryRead } from "./message_read.mjs";
import { earlierAdmittedExistsSql } from "./delivery_admission.mjs";
import { receiveOrderBy } from "./message_shared.mjs";

// Any live session receives any delivery addressed to it (Joe, 2026-10-25;
// ac-jfv.26/.27). Launch kind, admission windows, and claimed resume requests
// only decide how tldr shows a message; receipt needs the asker to be the
// endpoint's current process. The other receipt paths keep their bookkeeping
// when they match; this one reads only unread deliveries, oldest first.
export function exactLiveSessionReceipt(db, input, appId) {
  return db
    .prepare(
      `SELECT d.id AS delivery_id, m.id AS message_id, m.conversation_id, m.body,
              e.id AS endpoint_id, e.process_generation, e.provider_session_id
         FROM deliveries d
         JOIN messages m ON m.id = d.message_id
         JOIN endpoints e ON e.id = d.endpoint_id
        WHERE d.message_id = ? AND d.state != 'failed' AND d.read_at IS NULL
          AND e.id = ? AND e.process_generation = ? AND e.provider_session_id = ?
          AND e.created_by_app_id = ? AND e.state IN ('idle', 'busy')
          AND NOT ${earlierAdmittedExistsSql("d", "earlier", "earlier.endpoint_id = e.id AND earlier.state != 'failed' AND earlier.read_at IS NULL")}
        ORDER BY ${receiveOrderBy("d")}
        LIMIT 1`,
    )
    .get(
      input.message_id,
      input.endpoint_id,
      input.process_generation,
      input.provider_session_id,
      appId,
    );
}

// Reads the delivery (which completes its resume requests). A daemon resume
// claimed for it stays recorded as served by this process, as ordinary
// recovery records it.
export function admitLiveSessionReceipt(db, live, input) {
  const now = new Date().toISOString();
  db.prepare(
    `UPDATE resume_requests
        SET admitted_at = ?, admitted_process_generation = ?, admitted_provider_session_id = ?, updated_at = ?
      WHERE endpoint_id = ? AND message_id = ? AND state = 'claimed'
        AND admitted_at IS NULL AND admitted_process_generation IS NULL AND admitted_provider_session_id IS NULL`,
  ).run(
    now,
    input.process_generation,
    input.provider_session_id,
    now,
    live.endpoint_id,
    live.message_id,
  );
  if (
    !markExactDeliveryRead(db, {
      deliveryId: live.delivery_id,
      endpointId: live.endpoint_id,
      now,
    })
  ) {
    throw new TightbeamError(
      "listener_conflict",
      "live session delivery is no longer readable",
    );
  }
  return now;
}

// The receive boundary log names the receipt path that admitted the message.
export function logReceiptAdmitted(logger, input, result) {
  logger?.info?.({
    event: "message_receive_admitted",
    params: {
      message_id: input.message_id,
      endpoint_id: input.endpoint_id,
      process_generation: input.process_generation,
    },
    result,
    status: "ok",
  });
}

// A dead endpoint has no receipt path until a session re-registers it
// (endpoint.register revives a dead row). Say so, and give the agent CLI a
// stable reason to re-register and retry on (agent_commands runAgentCommand).
// Dead outranks a stale cached generation: registering fixes both, and the
// stale text would hide the cause (round-2 finding 3).
// Only the endpoint's own application and provider session may learn it is
// dead (or that its id exists); anyone else gets the generic refusal.
export function noReceiptRefusal({
  endpoint,
  appId,
  providerSessionId,
  messageId,
  message,
}) {
  const own =
    endpoint?.created_by_app_id === appId &&
    endpoint.provider_session_id === providerSessionId;
  if (!own || endpoint.state !== "dead")
    return new TightbeamError("permission_denied", message);
  return new TightbeamError(
    "permission_denied",
    "this session's endpoint is recorded dead, so it has no receipt path for this message until the session re-registers (its SessionStart hook does this); the message stays unread",
    {
      reason: "endpoint_dead",
      endpoint_state: "dead",
      // The dead custody observed: the CLI recovery revives exactly this one.
      process_generation: endpoint.process_generation,
      message_id: messageId,
    },
  );
}
